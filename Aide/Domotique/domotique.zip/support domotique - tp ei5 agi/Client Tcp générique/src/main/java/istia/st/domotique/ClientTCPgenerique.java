package istia.st.domotique;

// paquetages import�s
import java.io.*;
import java.net.*;

public class ClientTCPgenerique {

	// re�oit en param�tre les caract�ristiques d'un service sous la forme
	// serveur port
	// se connecte au service
	// cr�e un thread pour lire des commandes tap�es au clavier
	// celles-ci seront envoy�es au serveur
	// cr�e un thread pour lire les r�ponses du serveur
	// celles-ci seront affich�es � l'�cran
	// le tout se termine avec la commande fin tap�e au clavier

	// variable d'instance
	private static Socket client;

	public static void main(String[] args) {

		// syntaxe
		final String syntaxe = "pg serveur port";

		// nombre d'arguments
		if (args.length != 2)
			erreur(syntaxe, 1);

		// on note le nom du serveur
		String serveur = args[0];

		// le port doit �tre entier >0
		int port = 0;
		boolean erreurPort = false;
		Exception E = null;
		try {
			port = Integer.parseInt(args[1]);
		} catch (Exception e) {
			E = e;
			erreurPort = true;
		}
		erreurPort = erreurPort || port <= 0;
		if (erreurPort)
			erreur(syntaxe + "\n" + "Port incorrect (" + E + ")", 2);

		client = null;
		// il peut y avoir des probl�mes
		try {
			// on se connecte au service
			client = new Socket(serveur, port);
		} catch (Exception ex) {
			// erreur
			erreur("Impossible de se connecter au service (" + serveur + "," + port + "), erreur : " + ex.getMessage(), 3);
			// fin
			return;
		}//catch

		// on cr�e les threads de lecture/�criture
		new ClientSend(client).start();
		new ClientReceive(client).start();

		// fin thread main
		return;
	}// main

	// affichage des erreurs
	public static void erreur(String msg, int exitCode) {
		// affichage erreur
		System.err.println(msg);
		// arr�t avec erreur
		System.exit(exitCode);
	}//erreur
}//classe  

class ClientSend extends Thread {
	// classe charg�e de lire des commandes tap�es au clavier
	// et de les envoyer � un serveur via un client tcp pass� en param�tre

	private Socket client; // le client tcp

	// constructeur
	public ClientSend(Socket client) {
		// on note le client tcp
		this.client = client;
	}//constructeur

	// m�thode Run du thread
	public void run() {

		// donn�es locales
		PrintWriter OUT = null; // flux d'�criture r�seau
		BufferedReader IN = null; // flux clavier
		String commande = null; // commande lue au clavier

		// gestion des erreurs
		try {
			// cr�ation du flux d'�criture r�seau
			OUT = new PrintWriter(client.getOutputStream(), true);
			// cr�ation du flux d'entr�e clavier
			IN = new BufferedReader(new InputStreamReader(System.in));
			// boucle saisie-envoi des commandes
			System.out.println("Commandes : ");
			while (true) {
				// lecture commande tap�e au clavier
				commande = IN.readLine().trim();
				// fini ?
				if (commande.toLowerCase().equals("fin"))
					break;
				// envoi commande au serveur
				OUT.println(commande);
				// commande suivante
			}//while
		} catch (Exception ex) {
			// erreur
			System.err.println("Envoi : L'erreur suivante s'est produite : " + ex.getMessage());
		}//catch
			// fin - on ferme les flux
		try {
			OUT.close();
			client.close();
		} catch (Exception ex) {
		}
		// on signale la fin du thread
		System.out.println("[Envoi : fin du thread d'envoi des commandes au serveur]");
	}//run
}//classe

class ClientReceive extends Thread {
	// classe charg�e de lire les lignes de texte destin�es � un 
	// client tcp pass� en param�tre

	private Socket client; // le client tcp

	// constructeur
	public ClientReceive(Socket client) {
		// on note le client tcp
		this.client = client;
	}//constructeur

	// m�thode Run du thread
	public void run() {

		// donn�es locales
		BufferedReader IN = null; // flux lecture r�seau
		String r�ponse = null; // r�ponse serveur

		// gestion des erreurs
		try {
			// cr�ation du flux lecture r�seau
			IN = new BufferedReader(new InputStreamReader(client.getInputStream()));
			// boucle lecture lignes de texte du flux IN
			while (true) {
				// lecture flux r�seau
				r�ponse = IN.readLine();
				// flux ferm� ?
				if (r�ponse == null)
					break;
				// affichage
				System.out.println("<-- " + r�ponse);
			}//while
		} catch (Exception ex) {
			// erreur
			System.err.println("R�ception : L'erreur suivante s'est produite : " + ex.getMessage());
		}//catch
			// fin - on ferme les flux
		try {
			IN.close();
			client.close();
		} catch (Exception ex) {
		}
		// on signale la fin du thread
		System.out.println("[R�ception : fin du thread de lecture des r�ponses du serveur]");
	}//run
}//classe
