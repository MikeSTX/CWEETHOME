package istia.st.domotique;

// paquetages
import java.io.*;
import java.net.*;

public class ServeurTcpGenerique {
// programme principal
  public static void main(String[] args) {
// reçoit le port d'écoute des demandes des clients
// crée un thread pour lire les demandes du client
// celles-ci seront affichées à l'écran
// crée un thread pour lire des commandes tapées au clavier
// celles-ci seront envoyées comme réponse au client
// le tout se termine avec la commande fin tapée au clavier
    final String syntaxe = "Syntaxe : pg port";
// variable d'instance
// y-a-t-il un argument
    if (args.length != 1) {
      erreur(syntaxe, 1);
    }
// le port doit être entier >0
    int port = 0;
    boolean erreurPort = false;
    Exception E = null;
    try {
      port = Integer.parseInt(args[0]);
    } catch (Exception e) {
      E = e;
      erreurPort = true;
    }
    erreurPort = erreurPort || port <= 0;
    if (erreurPort) {
      erreur(syntaxe + "\n" + "Port incorrect (" + E + ")", 2);
    }
// on crée le servive d'écoute
    ServerSocket ecoute = null;
    int nbClients = 0; // nbre de clients traités
    try {
// on crée le service
      ecoute = new ServerSocket(port);
// suivi
      System.out.println("Serveur générique lancé sur le port " + port);
// boucle de service aux clients
      Socket client = null;
      while (true) { // boucle infinie - sera arrêtée par Ctrl-C
// attente d'un client
        client = ecoute.accept();
// le service est assuré des threads séparés
        nbClients++;
// on crée les threads de lecture/écriture
        new ServeurSend(client, nbClients).start();
        new ServeurReceive(client, nbClients).start();
// on retourne à l'écoute des demandes
      }// fin while
    } catch (Exception ex) {
// on signale l'erreur
      erreur("L'erreur suivante s'est produite : " + ex.getMessage(), 3);
    }//catch
  }// fin main
// affichage des erreurs
  public static void erreur(String msg, int exitCode) {
// affichage erreur
    System.err.println(msg);
// arrêt avec erreur
    System.exit(exitCode);
  }//erreur
}//classe

class ServeurSend extends Thread {
// classe chargée de lire des réponses tapées au clavier
// et de les envoyer à un client via un client tcp passé au constructeur
  Socket client;// le client tcp
  int numClient; // n° de client
// constructeur
  public ServeurSend(Socket client, int numClient) {
// on note le client tcp
    this.client = client;
// et son n°
    this.numClient = numClient;
  }//constructeur
// méthode Run du thread
  public void run() {
// données locales
    PrintWriter OUT = null; // flux d'écriture réseau
    String réponse = null; // réponse lue au clavier
    BufferedReader IN = null; // flux clavier
// suivi
    System.out.println("Thread de lecture des réponses du serveur au client " + numClient + " lancé");
// gestion des erreurs
    try {
// création du flux d'écriture réseau
      OUT = new PrintWriter(client.getOutputStream(), true);
// création du flux clavier
      IN = new BufferedReader(new InputStreamReader(System.in));
// boucle saisie-envoi des commandes
      while (true) {
// identification client
        System.out.print("--> " + numClient + " : ");
// lecture réponse tapée au clavier
        réponse = IN.readLine().trim();
// fini ?
        if (réponse.toLowerCase().equals("fin")) {
          break;
        }
// envoi réponse au serveur
        OUT.println(réponse);
// réponse suivante
      }//while
    } catch (Exception ex) {
// erreur
      System.err.println("L'erreur suivante s'est produite : " + ex.getMessage());
    }//catch
// fin - on ferme les flux
    try {
      OUT.close();
      client.close();
    } catch (Exception ex) {
    }
// on signale la fin du thread
    System.out.println("[fin du Thread de lecture des réponses du serveur au client " + numClient + "]");
  }//run
}//classe

class ServeurReceive extends Thread {
// classe chargée de lire les lignes de texte envoyées au serveur
// via un client tcp passé au constructeur
  Socket client;// le client tcp
  int numClient; // n° de client
// constructeur
  public ServeurReceive(Socket client, int numClient) {
// on note le client tcp
    this.client = client;
// et son n°
    this.numClient = numClient;
  }//constructeur
// méthode Run du thread
  public void run() {
// données locales
    BufferedReader IN = null; // flux lecture réseau
    String réponse = null; // réponse serveur
// suivi
    System.out.println("Thread de lecture des demandes du client " + numClient + " lancé");
// gestion des erreurs
    try {
// création du flux lecture réseau
      IN = new BufferedReader(new InputStreamReader(client.getInputStream()));
// boucle lecture lignes de texte du flux IN
      while (true) {
// lecture flux réseau
        réponse = IN.readLine();
// flux fermé ?
        if (réponse == null) {
          break;
        }
// affichage
        System.out.println("<-- " + réponse);
      }//while
    } catch (Exception ex) {
// erreur
      System.err.println("L'erreur suivante s'est produite : " + ex.getMessage());
    }//catch
// fin - on ferme les flux
    try {
      IN.close();
      client.close();
    } catch (Exception ex) {
    }
// on signale la fin du thread
    System.out.println("[fin du Thread de lecture des demandes du client " + numClient + "]");
  }//run
}//classe