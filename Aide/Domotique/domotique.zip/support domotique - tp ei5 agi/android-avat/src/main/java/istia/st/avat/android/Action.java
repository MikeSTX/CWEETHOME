package istia.st.avat.android;

import istia.st.avat.core.IAction;
import istia.st.avat.core.IBoss;
import istia.st.avat.core.IFactory;
import istia.st.avat.core.ITeam;
import istia.st.avat.core.IWorker;

public abstract class Action implements IAction {

	// ses deux identités
	protected String bossId;
	protected String workerId;

	// la vue qui demande l'action
	protected IBoss boss;

	// l'équipe de tâches qui travaillent pour l'action
	private ITeam team;

	// la factory
	protected IFactory factory;

	// l'action en tant que IWorker peut être annulée par le boss
	public void cancel() {
		// l'action annule toutes les tâches qu'elle a lancées
		cancelAll();
	}

	// on gère certains événements
	public void notifyEvent(IWorker worker, int eventType, Object event) {
		// on passe l'événement à l'équipe de tâches
		team.notifyEvent(worker, eventType, event);
	}

	// l'action en tant que IBoss peut annuler le travail d'un de ses travailleurs
	public void cancel(IWorker worker) {
		// on délègue à l'équipe
		team.cancel(worker);
	}

	// l'action en tant que IBoss peut annuler le travail de tous ses travailleurs
	public void cancelAll() {
		// on délègue à l'équipe
		team.cancelAll();
	}

	// l'action en tant que IBoss peut annuler le travail d'un de ses travailleurs
	public void cancel(String workerId) {
		// on délègue à l'équipe
		team.cancel(workerId);
	}

	// début du monitoring
	public void beginMonitoring() {
		team.beginMonitoring();
	}

	// état verbeux
	public void setVerbose(boolean verbose) {
		team.setVerbose(verbose);
	}

	// méthodes de la classe fille
	// la classe fille fait le travail
	abstract public void doWork(Object... params);

	// elle veut être prévenue de la fin des tâches
	abstract public void notifyEndOfTasks();

	// getters et setters
	public void setTeam(ITeam team) {
		this.team = team;
	}

	public void setBoss(IBoss boss) {
		this.boss = boss;
	}

	public void setWorkerId(String id) {
		this.workerId = id;
	}

	public String getWorkerId() {
		return workerId;
	}

	public void setFactory(IFactory factory) {
		this.factory = factory;

	}

	public void setBossId(String id) {
		this.bossId = id;
	}

	public String getBossId() {
		return bossId;
	}

}
