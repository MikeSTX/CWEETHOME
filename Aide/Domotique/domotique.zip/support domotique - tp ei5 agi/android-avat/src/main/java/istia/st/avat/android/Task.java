package istia.st.avat.android;

import istia.st.avat.core.IBoss;
import istia.st.avat.core.IFactory;
import istia.st.avat.core.ITask;
import android.os.AsyncTask;

public abstract  class Task extends AsyncTask<Object, Object, Void> implements ITask {

  // la tâche est identifiée
  protected String id;

  // la tâche a un boss
  protected IBoss boss;

  // la factory
  protected IFactory factory;

  // mode verbose
  protected boolean verbose;
  
  // annulation de la tâche
  public void cancel() {
    // la tâche est annulée
    cancel(true);
  }

  // la tâche fille fait un travail
  public void doWork(Object... params) {
    // le travail est fait en tâche de fond
    this.executeOnExecutor(THREAD_POOL_EXECUTOR, params);
  }

  // getters et setters
  public void setBoss(IBoss boss) {
    this.boss = boss;
  }

  public void setWorkerId(String id) {
    this.id = id;
  }

  public String getWorkerId() {
    return id;
  }

  public void setFactory(IFactory factory) {
    this.factory = factory;

  }

  public void setVerbose(boolean verbose) {
    this.verbose=verbose;    
  }

}
