package istia.st.avat.android;

import istia.st.avat.core.IBoss;
import istia.st.avat.core.ITeam;
import istia.st.avat.core.IWorker;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import android.util.Log;

public class Team implements ITeam {

	// toutes les méthodes de cette classe s'exécutent dans le thread de l'UI
	// c'est pourquoi elles ne sont pas synchronisées

	// la liste des travailleurs de l'équipe
	private List<IWorker> workers = new ArrayList<IWorker>();
	// le monitoring
	private Boolean isMonitoring = false;
	// le monitor de l'équipe
	private IBoss monitor;
	// état verbeux ou non
	private boolean verbose;

	// recherche d'un travailleur à partir de son id
	private IWorker getWorkerById(String workerId) {
		for (IWorker worker : workers) {
			if (worker.getWorkerId().equals(workerId)) {
				// on a trouvé
				return worker;
			}
		}
		// on n'a pas trouvé
		return null;
	}

	// annulation du travail d'un travailleur
	public void cancel(IWorker worker) {
		// on demande au travailleur d'arrêter son travail
		worker.cancel();
		// on le supprime de l'équipe
		workers.remove(worker);
		// verbose ?
		if (verbose) {
			Log.i(worker.getWorkerId(), String.format("taskId=%s canceled at time=%s\n", worker.getWorkerId(),
					new SimpleDateFormat("hh:mm:ss:SS", Locale.FRANCE).format(new Date())));
		}
	}

	public void cancel(String workerId) {
		// on cherche le travailleur
		IWorker worker = getWorkerById(workerId);
		// on annule son travail si on l'a trouvé
		if (worker != null) {
			cancel(worker);
		}
	}

	// annulation de tous les travaux
	public void cancelAll() {
		// on les annule en partant de la fin de la liste
		int nbWorkers = workers.size();
		for (int i = nbWorkers - 1; i >= 0; i--) {
			cancel(workers.get(i));
		}
	}

	// on gère certains événements
	public void notifyEvent(IWorker worker, int eventType, Object event) {
		// verbose ?
		if (verbose) {
			Log.i(worker.getWorkerId(), String.format("eventType=%s,  taskId=%s, time=%s\n", IBoss.STATUS[eventType],
					worker.getWorkerId(), new SimpleDateFormat("hh:mm:ss:SS", Locale.FRANCE).format(new Date())));
		}
		// on s'intéresse à certains événements
		switch (eventType) {
		case IBoss.WORK_STARTED:
			// un nouveau travailleur
			workers.add(worker);
			break;
		case IBoss.WORK_TERMINATED:
			// un travailleur a terminé son travail
			workers.remove(worker);
			// fin des travailleurs ?
			if (isMonitoring && workers.size() == 0) {
				// on l'indique au monitor
				monitor.notifyEndOfTasks();
			}
			break;
		}
	}

	// le boss veut être prévenu de la fin des travaux
	public void beginMonitoring() {
		// on monitore
		isMonitoring = true;
		// on vérifie tout de suite s'il reste des travailleurs
		if (workers.size() == 0) {
			// on l'indique au monitor
			monitor.notifyEndOfTasks();
		}

	}

	// getters et setters
	public void setMonitor(IBoss monitor) {
		this.monitor = monitor;
	}

	public void setVerbose(boolean verbose) {
		this.verbose = verbose;
	}

}
