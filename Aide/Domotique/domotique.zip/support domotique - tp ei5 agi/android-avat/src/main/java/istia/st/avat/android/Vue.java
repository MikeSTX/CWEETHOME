package istia.st.avat.android;

import istia.st.avat.core.IBoss;
import istia.st.avat.core.IFactory;
import istia.st.avat.core.ITeam;
import istia.st.avat.core.IVue;
import istia.st.avat.core.IWorker;
import android.app.Activity;
import android.app.Fragment;

public abstract class Vue extends Fragment implements IVue {

	// son identité
	protected String bossId;
	// la vue a une équipe d'actions qui travaillent pour elle
	private ITeam team;
	// la vue travaille avec une activité
	protected Activity activity;

	// la factory
	protected IFactory factory;

	// la vue gère des événements
	public void notifyEvent(IWorker worker, int eventType, Object event) {
		// on passe l'événement à l'équipe d'actions
		team.notifyEvent(worker, eventType, event);
	}

	public void cancel(IWorker worker) {
		// on délègue à l'équipe
		team.cancel(worker);

	}

	public void cancelAll() {
		// on délègue à l'équipe
		team.cancelAll();

	}

	public void cancel(String workerId) {
		// on délègue à l'équipe
		team.cancel(workerId);

	}

	// le monitor de l'équipe
	public void setMonitor(IBoss monitor) {
		team.setMonitor(monitor);

	}

	// début du monitoring
	public void beginMonitoring() {
		team.beginMonitoring();
	}

	// état verbeux
	public void setVerbose(boolean verbose) {
		team.setVerbose(verbose);
	}

	// méthodes implémentées par la classe fille
	abstract public void notifyEndOfTasks();

	// getters et setters
	public void setFactory(IFactory factory) {
		this.factory = factory;

	}

	public void setActivity(Activity activity) {
		this.activity = activity;
	}

	public void setTeam(ITeam team) {
		this.team = team;
	}

	public void setBossId(String id) {
		this.bossId = id;

	}

	public String getBossId() {
		return bossId;
	}

}
