package istia.st.avat.core;

public interface IAction extends IBoss, IWorker {

}
