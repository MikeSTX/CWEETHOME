package istia.st.avat.core;

public interface IBoss {

  // les types d'événements
  static final int WORK_STARTED = 0;
  static final int WORK_INFO = 1;
  static final int WORK_TERMINATED = 2;
  static final String[] STATUS = { "WORK_STARTED", "WORK_INFO", "WORK_TERMINATED" };

  // le boss a une identité
  public void setBossId(String id);

  public String getBossId();

  // un boss a accès à la factory
  public void setFactory(IFactory factory);

  // le boss gère une équipe de workers
  public void setTeam(ITeam team);

  // il reçoit des notifications de ses workers
  public void notifyEvent(IWorker worker, int eventType, Object event);

  // il peut annuler un travail
  public void cancel(IWorker worker);

  public void cancel(String workerId);

  // il peut annuler tous les travaux
  public void cancelAll();

  // on lui signale la fin des travaux
  public void notifyEndOfTasks();

  // il monitore ses travailleurs
  public void beginMonitoring();

  // le boss peut travailler en mode verbeux
  public void setVerbose(boolean verbose);
}
