package istia.st.avat.core;

public interface IFactory {
  // fabrique d'objets
  public Object getObject(int id, Object... params);

}
