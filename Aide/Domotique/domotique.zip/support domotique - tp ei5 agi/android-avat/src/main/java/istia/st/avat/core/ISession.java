package istia.st.avat.core;

public interface ISession {
  // ajoute un élément dans la session
  void add(String id, Object value);
  // enlève un élément de la session
  void remove(String id);
  // recherche d'un élément
  Object get(String id);
  // vide la session
  void clear();
}
