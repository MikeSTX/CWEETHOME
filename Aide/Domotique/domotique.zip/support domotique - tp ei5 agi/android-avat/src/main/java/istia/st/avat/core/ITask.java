package istia.st.avat.core;

public interface ITask extends IWorker {

}
