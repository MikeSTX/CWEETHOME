package istia.st.avat.core;

// une équipe de travailleurs
public interface ITeam {

  // l'équipe gère une équipe de travailleurs
  // elle exécute les ordre d'un boss

  // l'équipe a un monitor
  public void setMonitor(IBoss boss);

  // l'équipe reçoit des notifications des travailleurs via le boss
  public void notifyEvent(IWorker worker, int eventType, Object event);

  // le boss peut annuler le travail d'un travailleur
  public void cancel(IWorker worker);

  public void cancel(String workerId);

  // le boss annule tout
  public void cancelAll();

  // le boss envoie cet ordre lorsqu'il veut être prévenu de la fin des tâches
  public void beginMonitoring();

  // l'équipe peut être verbeuse
  public void setVerbose(boolean verbose);
}
