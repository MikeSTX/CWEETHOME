package istia.st.avat.core;


public interface IVue extends IBoss {
}
