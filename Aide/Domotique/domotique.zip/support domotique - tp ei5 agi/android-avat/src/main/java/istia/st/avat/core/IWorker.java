package istia.st.avat.core;

public interface IWorker {

  // a accès à la factory
  public void setFactory(IFactory factory);

  // un worker sait faire un travail
  public void doWork(Object... params);

  // il a un patron
  public void setBoss(IBoss boss);

  // il a une identité
  public void setWorkerId(String id);

  public String getWorkerId();

  // son travail peut être annulé
  public void cancel();

}
