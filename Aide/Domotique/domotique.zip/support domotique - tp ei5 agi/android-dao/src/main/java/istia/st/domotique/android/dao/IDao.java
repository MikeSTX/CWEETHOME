package istia.st.domotique.android.dao;
import java.util.Map;

public interface IDao {
  public String executeRestService(String method, String urlService, Object request, Map<String, String> paramètres);
  public void setTimeout(int millis);
}