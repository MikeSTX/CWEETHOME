package istia.st.domotique.android.metier;

import istia.st.domotique.android.dao.IDao;
import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.Reponse;

import java.util.Collection;
import java.util.List;


public interface IMetier {
  // liste des arduinos
  public Collection<Arduino> getArduinos(String urlServiceRest);
  // lecture d'une pin
  public Reponse pinRead(String urlServiceRest,String idCommande, String idArduino, int pin, String mode);
  // écriture d'une pin
  public Reponse pinWrite(String urlServiceRest,String idCommande, String idArduino, int pin, String mode,int val);
  // faire clignoter une led
  public Reponse faireClignoterLed(String urlServiceRest,String idCommande, String idArduino, int pin, int millis, int nbIter);
  // envoyer une suite de commandes Json à un Arduino
  public List<String> sendCommandesJson(String urlServiceRest,String idArduino, List<String> commandes);
  // envoyer une suite de commandes à un Arduino
  public List<Reponse> sendCommandes(String urlServiceRest,String idArduino, List<Commande> commandes);
  // la couche [dao]
  public void setDao(IDao dao);
}
