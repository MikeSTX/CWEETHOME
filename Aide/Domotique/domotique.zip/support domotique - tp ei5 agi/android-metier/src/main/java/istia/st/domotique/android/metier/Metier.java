package istia.st.domotique.android.metier;

import istia.st.domotique.android.dao.IDao;
import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.DomotiqueException;
import istia.st.domotique.entities.Reponse;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Metier implements IMetier {

	// couche [dao]
	private IDao dao;
	// mapper JSON
	private Gson gson = new Gson();

	public Collection<Arduino> getArduinos(String urlServiceRest) {
		// suivi
		System.out.println(String.format("métier getArduinos %s : %s %s", new SimpleDateFormat("hh:mm:ss:SS", Locale.FRANCE).format(new Date()),
				urlServiceRest, dao == null));

		// adresse du service REST
		String urlService = String.format("http://%s/arduinos/", urlServiceRest);
		// on demande la liste des Arduinos au service REST
		String réponse = dao.executeRestService("get", urlService, null, new HashMap<String, String>());
		// on exploite la réponse
		try {
			// résultat
			return gson.fromJson(réponse, new TypeToken<Collection<Arduino>>() {
			}.getType());
		} catch (Exception ex) {
			throw new DomotiqueException(String.format("Réponse incorrecte du serveur: %s", réponse), ex, 167);
		}
	}

	public Reponse pinRead(String urlServiceRest, String idCommande, String idArduino, int pin, String mode) {
		return null;
	}

	public Reponse pinWrite(String urlServiceRest, String idCommande, String idArduino, int pin, String mode, int val) {
		return null;
	}

	public Reponse faireClignoterLed(String urlServiceRest, String idCommande, String idArduino, int pin, int millis, int nbIter) {
		return null;
	}

	public List<String> sendCommandesJson(String urlServiceRest, String idArduino, List<String> commandes) {
		return null;
	}

	public List<Reponse> sendCommandes(String urlServiceRest, String idArduino, List<Commande> commandes) {
		return null;
	}

	// getters et setters
	public void setDao(IDao dao) {
		this.dao = dao;
	}

}
