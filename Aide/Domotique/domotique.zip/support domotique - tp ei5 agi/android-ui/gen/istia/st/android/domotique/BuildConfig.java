/** Automatically generated file. DO NOT MODIFY */
package istia.st.android.domotique;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}