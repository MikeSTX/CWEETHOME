package istia.st.domotique.android.actions;

import istia.st.avat.android.Action;
import istia.st.avat.android.Task;
import istia.st.avat.core.IBoss;
import istia.st.avat.core.IWorker;
import istia.st.domotique.android.activity.Factory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ConfigAction extends Action {

  @Override
  // urlServiceRest
  public void doWork(Object... params) {
    
    // suivi
    String urlServiceRest = (String) params[0];
    System.out.println(String.format("ConfigAction %s : %s %s", workerId, new SimpleDateFormat("hh:mm:ss:SS",
        Locale.FRANCE).format(new Date()), urlServiceRest));
    
    // on crée la tâche asynchrone
    Task configTask = (Task) factory.getObject(Factory.CONFIG_TASK,this, "configTask");
    // on lance la tâche (urlServiceRest)
    configTask.doWork(params);
    // on commence le monitoring de la tâche
    beginMonitoring();
  }

  @Override
  public void notifyEndOfTasks() {
    // fin de l'action
    boss.notifyEvent(this, IBoss.WORK_TERMINATED, null);
  }

  // on gère certains événements
  public void notifyEvent(IWorker worker, int eventType, Object event) {
    // on passe l'événement au parent
    super.notifyEvent(worker, eventType, event);
    // on gère le type WORK_INFO
    if (eventType == IBoss.WORK_INFO) {
      // on passe l'info brute au boss
      boss.notifyEvent(this, eventType, event);
    }
  }

}
