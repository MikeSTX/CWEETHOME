package istia.st.domotique.android.activity;

public class Config {
  // ici on met la config de l'application

  // propriété verbose - à vrai on loguera les évts des tâches (WORK_STARTED,
  // WORK_TERMINATED, WORK_INFO, CANCELLED)
  private boolean verbose = true;
  // timeout des connexions au serveur
  private int timeout=1000;
  
  // getters
  public boolean getVerbose() {
    return verbose;
  }

	public int getTimeout() {
		return timeout;
	}
  
}
