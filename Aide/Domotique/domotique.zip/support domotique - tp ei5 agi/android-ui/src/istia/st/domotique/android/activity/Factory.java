package istia.st.domotique.android.activity;

import istia.st.avat.android.Team;
import istia.st.avat.android.Vue;
import istia.st.avat.core.IAction;
import istia.st.avat.core.IBoss;
import istia.st.avat.core.IFactory;
import istia.st.avat.core.ISession;
import istia.st.avat.core.ITask;
import istia.st.avat.core.ITeam;
import istia.st.domotique.android.actions.ConfigAction;
import istia.st.domotique.android.dao.Dao;
import istia.st.domotique.android.dao.IDao;
import istia.st.domotique.android.metier.IMetier;
import istia.st.domotique.android.metier.Metier;
import istia.st.domotique.android.tasks.ConfigTask;
import istia.st.domotique.android.vues.BlinkVue;
import istia.st.domotique.android.vues.CommandVue;
import istia.st.domotique.android.vues.ConfigVue;
import istia.st.domotique.android.vues.PinReadVue;
import istia.st.domotique.android.vues.PinWriteVue;
import android.app.Activity;

public class Factory implements IFactory {

  // constantes
  public final static int CONFIG = 0;
  public final static int METIER = 1;
  public final static int SESSION = 2;

  // les vues
  public final static int BLINK_VUE = 101;
  public final static int CONFIG_VUE = 102;
  public final static int PINWRITE_VUE = 103;
  public final static int PINREAD_VUE = 104;
  public final static int COMMAND_VUE = 105;
  // les actions
  public final static int BLINK_ACTION = 201;
  public final static int CONFIG_ACTION = 202;
  public final static int PINWRITE_ACTION = 203;
  public final static int PINREAD_ACTION = 204;
  public final static int COMMAND_ACTION = 205;
  // les tâches
  public final static int BLINK_TASK = 301;
  public final static int CONFIG_TASK = 302;
  public final static int PINWRITE_TASK = 303;
  public final static int PINREAD_TASK = 304;
  public final static int COMMAND_TASK = 305;

  // ------------------------------------- DEBUT SINGLETONS
  // la configuration
  private Config config;
  private boolean verbose;
  private int timeout;
  
  // la couche métier
  private IMetier metier;

  // la session
  private ISession session;

  // les vues
  private Vue configVue;
  private Vue blinkVue;
  private Vue pinReadVue;
  private Vue pinWriteVue;
  private Vue commandVue;

  // l'activité principale
  private Activity activity;

  // ------------------------------------- FIN SINGLETONS

  // constructeur
  public Factory(Activity activity, Config config) {
    this.activity = activity;
    this.config = config;
    verbose = config.getVerbose();
    timeout=config.getTimeout();
  }

  // ------------------------------------- getObject
  public Object getObject(int id, Object... params) {
    switch (id) {
    case CONFIG:
      return config;
    case CONFIG_VUE:
      return getConfigVue();
    case BLINK_VUE:
      return getBlinkVue();
    case COMMAND_VUE:
      return getCommandVue();
    case PINWRITE_VUE:
      return getPinWriteVue();
    case PINREAD_VUE:
      return getPinReadVue();
    case CONFIG_ACTION:
      return getConfigAction(params);
    case CONFIG_TASK:
      return getConfigTask(params);
    case METIER:
      return getMetier();
    case SESSION:
      return getSession();
    }

    // pour le compilateur
    return null;
  }

  // session
  private Object getSession() {
    if (session == null) {
      session = new Session();
    }
    return session;
  }

  // couche métier
  private Object getMetier() {
    if (metier == null) {
      // couche dao
      IDao dao = new Dao();
      dao.setTimeout(timeout);
      // couche métier
      metier = new Metier();
      metier.setDao(dao);
    }
    return metier;
  }

  // initialisation d'une vue
  private void init(Vue vue) {
    vue.setFactory(this);
    ITeam team = new Team();
    team.setMonitor(vue);
    vue.setTeam(team);
    vue.setActivity(activity);
    vue.setVerbose(verbose);
    String longName = vue.getClass().getName();
    String[] parts = longName.split("\\.");
    vue.setBossId(parts[parts.length - 1]);
  }

  // pinReadVue
  private Object getPinReadVue() {
    if (pinReadVue == null) {
      pinReadVue = new PinReadVue();
      init(pinReadVue);
    }
    return pinReadVue;
  }

  // pinWriteVue
  private Object getPinWriteVue() {
    if (pinWriteVue == null) {
      pinWriteVue = new PinWriteVue();
      init(pinWriteVue);
    }
    return pinWriteVue;
  }

  // commandVue
  private Object getCommandVue() {
    if (commandVue == null) {
      commandVue = new CommandVue();
      init(commandVue);
    }
    return commandVue;
  }

  // blinkVue
  private Object getBlinkVue() {
    if (blinkVue == null) {
      blinkVue = new BlinkVue();
      init(blinkVue);
    }
    return blinkVue;
  }

  // configVue
  private Object getConfigVue() {
    if (configVue == null) {
      configVue = new ConfigVue();
      init(configVue);
    }
    return configVue;
  }

  // les tâches reçoivent deux paramètres : IBoss, id
  private Object getConfigTask(Object[] params) {
    ITask configTask = new ConfigTask();
    init(configTask, params);
    return configTask;
  }

  // iitialisation d'une tâche terminale
  private void init(ITask task, Object[] params) {
    task.setBoss((IBoss) params[0]);
    task.setWorkerId((String) params[1]);
    task.setFactory(this);
  }


  // les actions reçoivent deux paramètres : IBoss, id
  private Object getConfigAction(Object[] params) {
    IAction configAction = new ConfigAction();
    init(configAction, params);
    return configAction;
  }

  // initialisation d'une action
  private void init(IAction action, Object[] params) {
    action.setBoss((IBoss) params[0]);
    ITeam team = new Team();
    team.setMonitor(action);
    action.setTeam(team);
    action.setWorkerId((String) params[1]);
    action.setBossId((String) params[1]);
    action.setFactory(this);
    action.setVerbose(verbose);
  }
}
