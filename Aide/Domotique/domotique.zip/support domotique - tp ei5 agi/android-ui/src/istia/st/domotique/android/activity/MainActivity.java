package istia.st.domotique.android.activity;

import istia.st.android.domotique.R;
import istia.st.avat.android.Vue;
import istia.st.avat.core.ISession;
import istia.st.domotique.entities.Arduino;
import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.Window;

public class MainActivity extends FragmentActivity implements ActionBar.TabListener {

  // on a 1 activité qui gère 5 vues (Fragments)
  // l'activité gère l'affichage de ces vues et les données qui leur sont
  // nécessaires - c'est tout

  // les 5 vues
  private TabVue[] tabVues = new TabVue[5];

  // exécuté à la création de l'activité
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    // parent
    super.onCreate(savedInstanceState);
    // le sablier
    requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);
    setProgressBarIndeterminateVisibility(false);
    // template qui accueille les vues
    setContentView(R.layout.main);
    // la factory
    Factory factory = new Factory(this, new Config());
    // la session
    ISession session = (ISession) factory.getObject(Factory.SESSION, (Object[]) null);
    // on y met l'activité
    //session.add("activity", this);
    // on fixe l'URL par défaut du service REST
    session.add("urlServiceRest", getText(R.string.edt_UrlServiceRest).toString());

    // on utilise des onglets dans la barre d'actions
    ActionBar actionBar = getActionBar();
    actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

    // on définit les 5 vues
    tabVues[0] = new TabVue(actionBar.newTab().setText(R.string.title_config).setTabListener(this),
        (Vue) factory.getObject(Factory.CONFIG_VUE, (Object[]) null));
    tabVues[1] = new TabVue(actionBar.newTab().setText(R.string.title_pinwrite).setTabListener(this),
        (Vue) factory.getObject(Factory.PINWRITE_VUE, (Object[]) null));
    tabVues[2] = new TabVue(actionBar.newTab().setText(R.string.title_pinread).setTabListener(this),
        (Vue) factory.getObject(Factory.PINREAD_VUE, (Object[]) null));
    tabVues[3] = new TabVue(actionBar.newTab().setText(R.string.title_blink).setTabListener(this),
        (Vue) factory.getObject(Factory.BLINK_VUE, (Object[]) null));
    tabVues[4] = new TabVue(actionBar.newTab().setText(R.string.title_command).setTabListener(this),
        (Vue) factory.getObject(Factory.COMMAND_VUE, (Object[]) null));

    // au départ on a une liste d'arduinos vide dans la session
    session.add("arduinos", new Arduino[0]);

    // on affiche le 1er onglet
    showTabs(new Boolean[] { true, false, false, false, false });

  }

  // affichage de certains onglets
  public void showTabs(Boolean[] show) {
    // si show[i] est vrai, affiche la vue n° i
    ActionBar actionBar = getActionBar();
    // on passe ttes les vues en revue
    for (int i = 0; i < tabVues.length; i++) {
      Tab tab = tabVues[i].getTab();
      int position = tab.getPosition();
      if (show[i]) {
        // la vue doit être affichée si elle ne l'est pas déjà
        if (position == Tab.INVALID_POSITION) {
          actionBar.addTab(tab);
        }
      } else {
        // la vue doit être enlevée si elle ne l'est pas déjà
        if (position != Tab.INVALID_POSITION) {
          actionBar.removeTab(tab);
        }
      }
    }
  }

  // changement d'onglet
  @Override
  public void onTabSelected(ActionBar.Tab tab, FragmentTransaction fragmentTransaction) {
    // on cherche l'onglet sélectionné
    Boolean trouvé = false;
    int i = 0;
    while (!trouvé) {
      trouvé = tab == tabVues[i].getTab();
      i++;
    }
    // la vue de l'onglet sélectionné est installée dans son conteneur
    fragmentTransaction.replace(R.id.container, tabVues[i - 1].getVue());
  }

  @Override
  public void onTabReselected(Tab arg0, FragmentTransaction arg1) {
    // onglet resélectionné - on ne gère pas
  }

  @Override
  public void onTabUnselected(Tab arg0, FragmentTransaction arg1) {
    // onglet déselectionné - on ne gère pas
  }

}
