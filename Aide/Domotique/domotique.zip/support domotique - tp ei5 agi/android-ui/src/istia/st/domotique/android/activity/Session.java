package istia.st.domotique.android.activity;

import istia.st.avat.core.ISession;

import java.util.HashMap;
import java.util.Map;


public class Session implements ISession {

  // data
  Map<String, Object> session = new HashMap<String, Object>();

  public void add(String id, Object value) {
    session.put(id, value);

  }

  public void remove(String id) {
    session.remove(id);

  }

  public Object get(String id) {
    return session.get(id);
  }

  public void clear() {
    session.clear();

  }

}
