package istia.st.domotique.android.activity;

import istia.st.avat.android.Vue;
import android.app.ActionBar.Tab;


public class TabVue {
  // données
  private Tab tab;
  private Vue vue;

  // constructeurs
  public TabVue() {

  }

  public TabVue(Tab tab, Vue vue) {
    this.tab = tab;
    this.vue = vue;
  }

  // getters et setters

  public Tab getTab() {
    return tab;
  }

  public void setTab(Tab tab) {
    this.tab = tab;
  }

  public Vue getVue() {
    return vue;
  }

  public void setVue(Vue vue) {
    this.vue = vue;
  }
}
