package istia.st.domotique.android.tasks;

import istia.st.avat.android.Task;
import istia.st.avat.core.IBoss;
import istia.st.domotique.android.activity.Factory;
import istia.st.domotique.android.metier.IMetier;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class ConfigTask extends Task {

	// résultat de la tâche
	private Object info;

	// constructeurs
	public ConfigTask() {

	}

	@Override
	protected void onPreExecute() {
		// on est dans le thread de l'UI
		// la tâche démarre
		boss.notifyEvent(this, IBoss.WORK_STARTED, null);
	}

	@Override
	// on exécute la tâche (metier, urlServiceRest)
	protected Void doInBackground(Object... params) {

		// paramètres
    IMetier metier = (IMetier) factory.getObject(Factory.METIER, (Object[]) null);
		String urlServiceRest = (String) params[0];

		// suivi
		System.out.println(String.format("début ConfigTask %s doInBackground : %s %s", id, new SimpleDateFormat(
				"hh:mm:ss:SS", Locale.FRANCE).format(new Date()), urlServiceRest));

		// on exécute la méthode métier
		try {
			info = metier.getArduinos(urlServiceRest);
		} catch (Exception ex) {
			// on mémorise l'exception
			info = ex;
		}
		// pour le compilateur
		return null;
	}

	@Override
	protected void onPostExecute(Void result) {
		// on est dans le thread de l'UI
		// suivi
		System.out.println(String.format("fin ConfigTask %s doInBackground : %s", id, new SimpleDateFormat("hh:mm:ss:SS",
				Locale.FRANCE).format(new Date())));

		// on passe l'info au boss
		boss.notifyEvent(this, IBoss.WORK_INFO, info);
		// la tâche est terminée
		boss.notifyEvent(this, IBoss.WORK_TERMINATED, null);
	}

}
