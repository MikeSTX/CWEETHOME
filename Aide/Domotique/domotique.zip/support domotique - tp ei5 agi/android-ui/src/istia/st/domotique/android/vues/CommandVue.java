package istia.st.domotique.android.vues;

import istia.st.android.domotique.R;
import istia.st.avat.core.IWorker;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

public class CommandVue extends LocalVue {

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    // on crée la vue du fragment à partir de sa définition XML
    return inflater.inflate(R.layout.command, container, false);
  }

  @Override
  public void onActivityCreated(Bundle savedInstanceState) {
    // parent
    super.onActivityCreated(savedInstanceState);
  }

  // la vue gère des événements
  public void notifyEvent(IWorker worker, int eventType, Object event) {
  }

  @Override
  public void notifyEndOfTasks() {
  }

}
