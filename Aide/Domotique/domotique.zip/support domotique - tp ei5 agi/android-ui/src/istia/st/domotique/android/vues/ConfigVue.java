package istia.st.domotique.android.vues;

import istia.st.android.domotique.R;
import istia.st.avat.core.IAction;
import istia.st.avat.core.IBoss;
import istia.st.avat.core.IWorker;
import istia.st.domotique.android.activity.Factory;
import istia.st.domotique.entities.Arduino;

import java.net.URI;
import java.util.Collection;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

public class ConfigVue extends LocalVue {
  // l'interface visuelle
  private Button btnRafraichir;
  private Button btnAnnuler;
  private EditText edtUrlServiceRest;
  private TextView txtMsgErreurUrlServiceRest;
  private ListView listArduinos;

  // actions asynchrones
  private IAction configAction;

  // les données saisies
  private String urlServiceRest;

  // l'info reçue
  private Object info;

  @Override
  public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
    // on crée la vue du fragment à partir de sa définition XML
    return inflater.inflate(R.layout.config, container, false);
  }

  @Override
  public void onActivityCreated(Bundle savedInstanceState) {
    // parent
    super.onActivityCreated(savedInstanceState);
    // on définit la liste des arduinos
    listArduinos = (ListView) activity.findViewById(R.id.ListViewArduinos);
    listArduinos.setItemsCanFocus(false);

    // bouton Rafraîchir
    btnRafraichir = (Button) activity.findViewById(R.id.btn_Rafraichir);
    btnRafraichir.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View arg0) {
        doRafraichir();
      }
    });

    // bouton Annuler
    btnAnnuler = (Button) activity.findViewById(R.id.btn_Annuler);
    btnAnnuler.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View arg0) {
        // on annule l'action
        cancelAll();
        // on annule l'attente
        cancelWaiting();
        // on met à jour la vue principale
        mainActivity.showTabs(new Boolean[] { true, false, false, false, false });
      }
    });

    // visibilité boutons
    btnRafraichir.setVisibility(View.VISIBLE);
    btnAnnuler.setVisibility(View.INVISIBLE);

    // saisie de l'IP et du port du serveur
    edtUrlServiceRest = (EditText) activity.findViewById(R.id.edt_UrlServiceRest);
    edtUrlServiceRest.setText(R.string.edt_UrlServiceRest);

    // le msg d'erreur éventuel
    txtMsgErreurUrlServiceRest = (TextView) activity.findViewById(R.id.txt_MsgErreurIpPort);
  }

  // le fragment est désormais visible
  public void onStart() {
    // parent
    super.onStart();
    // pas de msg d'erreur
    txtMsgErreurUrlServiceRest.setText("");
    // affichage des arduinos
    showArduinos(listArduinos, false, null);
  }

  // rafraîchissement de la liste des arduinos
  public void doRafraichir() {
    // on vérifie les saisies
    if (!pageValid()) {
      return;
    }
    // c'est bon -on mémorise l'URI
    session.add("urlServiceRest", urlServiceRest);
    // on efface la liste des arduinos précédemment mémorisée
    // on les met dans la session
    session.add("arduinos", new Arduino[0]);
    // on les affiche
    showArduinos(listArduinos, false, null);
    // action asynchrone
    configAction = (IAction) factory.getObject(Factory.CONFIG_ACTION, this, "configAction");
    // on signale le début de l'action
    super.notifyEvent(configAction, WORK_STARTED, null);
    // début de l'attente
    beginWaiting();
    // exécution action
    configAction.doWork(urlServiceRest);
    // début du monitoring
    beginMonitoring();
  }

  // vérification des saisies
  private boolean pageValid() {
    // on récupère l'Ip et le port du serveur
    urlServiceRest = edtUrlServiceRest.getText().toString().trim();
    // on vérifie sa validité
    try {
      new URI(String.format("http://%s", urlServiceRest));
    } catch (Exception ex) {
      // affichage erreur
      showErreur(ex.getMessage(), null);
      // retour à l'UI
      return false;
    }
    // c'est bon
    txtMsgErreurUrlServiceRest.setText("");
    return true;
  }

  // affichage d'une erreur
  private void showErreur(String msg, Exception exception) {
    // on affiche l'erreur
    if (exception != null) {
      // affichage exception
      showException(exception);
    } else {
      // affichage msg d'erreur
      txtMsgErreurUrlServiceRest.setText(msg);
    }
    // pas d'arduinos
    session.add("arduinos", new Arduino[0]);
    showArduinos(listArduinos, false, null);
  }

  // la vue gère les événements provenant de l'action lancée
  public void notifyEvent(IWorker worker, int eventType, Object event) {
    // on passe l'événement à la Vue parent
    super.notifyEvent(worker, eventType, event);
    // on gère le type WORK_INFO
    if (eventType == IBoss.WORK_INFO) {
      // on note l'info
      info = event;
      // quel type d'info ?
      if (event instanceof Exception) {
        showException((Exception) event);
      } else if (event instanceof Collection<?>) {
        // on récupère le tableau d'arduinos
        @SuppressWarnings("unchecked")
        Arduino[] arduinos = ((Collection<Arduino>) event).toArray(new Arduino[0]);
        // on les met dans la session
        session.add("arduinos", arduinos);
        // on les affiche
        showArduinos(listArduinos, false, null);
      }
    }
  }

  @Override
  public void notifyEndOfTasks() {
    // on arrête d'attendre
    cancelWaiting();
    // selon l'info, les onglets à afficher ne sont pas les mêmes
    if (info instanceof Exception) {
      mainActivity.showTabs(new Boolean[] { true, false, false, false, false });
    } else {
      mainActivity.showTabs(new Boolean[] { true, true, true, true, true });
    }
  }

  // début de l'attente
  private void beginWaiting() {
    // on met le sablier
    showHourGlass();
    // boutons
    btnRafraichir.setVisibility(View.INVISIBLE);
    btnAnnuler.setVisibility(View.VISIBLE);
  }

  // fin de l'attente
  protected void cancelWaiting() {
    // on cache le sablier
    hideHourGlass();
    // visibilité boutons
    btnRafraichir.setVisibility(View.VISIBLE);
    btnAnnuler.setVisibility(View.INVISIBLE);
  }

}
