package istia.st.domotique.android.vues;

import istia.st.android.domotique.R;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;

public class ExceptionVue extends DialogFragment {

  // data
  private Exception ex;

  // constructeurs
  public ExceptionVue() {

  }

  public ExceptionVue(Exception ex) {
    this.ex = ex;
  }

  @Override
  public Dialog onCreateDialog(Bundle savedInstanceState) {
    // on construit le message
    String message = ex.getMessage();
    Throwable cause = ex.getCause();
    while (cause != null) {
      message += String.format("\n[%s, %s]", cause.getClass().getCanonicalName(), cause.getMessage());
      cause = cause.getCause();
    }
    // on construit la boîte de dialogue
    AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
    builder.setTitle(R.string.dialog_show_exception).setMessage(message)
        .setPositiveButton(R.string.dialog_show_exception_close, new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int id) {
            // rien
          }
        });
    // on la rend
    return builder.create();
  }
}
