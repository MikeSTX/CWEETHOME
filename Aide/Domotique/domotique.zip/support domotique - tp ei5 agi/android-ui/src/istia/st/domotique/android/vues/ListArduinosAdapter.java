package istia.st.domotique.android.vues;

import istia.st.android.domotique.R;
import istia.st.domotique.entities.Arduino;
import android.app.Activity;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.TextView;

public class ListArduinosAdapter extends ArrayAdapter<Arduino> {

  // le tableau des arduinos
  private Arduino[] arduinos;
  // le contexte d'exécution
  private Context context;
  // l'id du layout d'affichage d'une ligne de la liste des arduinos
  private int layoutResourceId;
  // la ligne comporte ou non un checkbox
  private Boolean selectable;

  // constructeur
  public ListArduinosAdapter(Context context, int layoutResourceId, Arduino[] arduinos, Boolean selectable) {
    super(context, layoutResourceId, arduinos);
    // on mémorise les infos
    this.arduinos = arduinos;
    this.context = context;
    this.layoutResourceId = layoutResourceId;
    this.selectable = selectable;
  }

  @Override
  public View getView(int position, View convertView, ViewGroup parent) {
    // la ligne à peupler
    View row = convertView;
    // déjà vue ?
    if (row == null) {
      // on crée la ligne
      row = ((Activity) context).getLayoutInflater().inflate(layoutResourceId, parent, false);
      TextView txtArduinoId = (TextView) row.findViewById(R.id.txt_arduino_id);
      TextView txtArduinoDesc = (TextView) row.findViewById(R.id.txt_arduino_description);
      // on remplit la ligne
      txtArduinoId.setText(arduinos[position].getId());
      txtArduinoDesc.setText(arduinos[position].getDescription());
      // checkbox ?
      CheckBox ck = (CheckBox) row.findViewById(R.id.checkBoxArduino);
      ck.setVisibility(selectable ? View.VISIBLE : View.INVISIBLE);
    }
    // on rend la ligne
    return row;
  }
}
