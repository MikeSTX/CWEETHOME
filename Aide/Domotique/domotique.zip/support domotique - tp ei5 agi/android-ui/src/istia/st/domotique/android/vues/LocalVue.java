package istia.st.domotique.android.vues;

import istia.st.android.domotique.R;
import istia.st.avat.android.Vue;
import istia.st.avat.core.ISession;
import istia.st.domotique.android.activity.Factory;
import istia.st.domotique.android.activity.MainActivity;
import istia.st.domotique.entities.Arduino;

import java.util.ArrayList;
import java.util.List;

import android.app.DialogFragment;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.ListView;

public abstract  class LocalVue extends Vue {
  // encapsule des méthodes et données communes aux classes filles
  protected ISession session;
  // la main activity
  protected MainActivity mainActivity;

  // constructeur
  public LocalVue() {
  }

  @Override
  public void onActivityCreated(Bundle savedInstanceState) {
    // parent
    super.onActivityCreated(savedInstanceState);
    // la session
    session = (ISession) factory.getObject(Factory.SESSION, (Object[]) null);
    // la main activity
    mainActivity= (MainActivity) activity;
  }

  // affichage de la liste des arduinos
  protected void showArduinos(ListView listArduinos, Boolean selectable, Arduino[] selectedArduinos) {

    // on définit la source de données de la liste
    Arduino[] arduinos = (Arduino[]) session.get("arduinos");
    ArrayAdapter<Arduino> adapter = new ListArduinosAdapter(getActivity(), R.layout.listarduinos_item, arduinos,
        selectable);
    listArduinos.setAdapter(adapter);
    // TODO sélectionner certains arduinos
    return;
  }

  // affichage exception
  protected void showException(Exception ex) {
    // on affiche l'exception dans une boîte de dialogue
    DialogFragment dialog = new ExceptionVue(ex);
    dialog.show(getFragmentManager(), "exception");
  }

  // arduinos sélectionnés dans la liste
  protected Arduino[] getSelectedArduinos(ListView listArduinos) {
    // la liste des arduinos
    Arduino[] arduinos = (Arduino[]) session.get("arduinos");
    List<Arduino> selectedArduinos = new ArrayList<Arduino>();
    // on parcourt la liste des arduinos
    for (int i = 0; i < listArduinos.getChildCount(); i++) {
      CheckBox ck = (CheckBox) listArduinos.getChildAt(i).findViewById(R.id.checkBoxArduino);
      if (ck.isChecked()) {
        selectedArduinos.add(arduinos[i]);
      }
    }
    // on rend le résultat
    return selectedArduinos.toArray(new Arduino[0]);
  }

  // gestion du sablier
  protected void showHourGlass() {
    mainActivity.setProgressBarIndeterminateVisibility(true);
  }

  protected void hideHourGlass() {
  	mainActivity.setProgressBarIndeterminateVisibility(false);
  }

  @Override
  abstract public void notifyEndOfTasks();
}
