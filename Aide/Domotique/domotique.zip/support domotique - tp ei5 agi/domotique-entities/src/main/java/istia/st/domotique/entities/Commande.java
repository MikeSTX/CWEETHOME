package istia.st.domotique.entities;

import java.io.IOException;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Commande implements Serializable {
	// données
	private static final long serialVersionUID = 1L;
	private String id;
	private String action;
	private Map<String, Object> parametres;
	private Map<String, Object> map = new HashMap<String, Object>();

	// constructeurs
	public Commande() {
	}

	public Commande(String id, String action, Map<String, Object> parametres) {
		// initialisation
		this.id = id;
		this.action = action;
		this.parametres = parametres;
		// construction de la map
		map.put("id", id);
		map.put("ac", action);
		map.put("pa", parametres);
	}

	// construction d'une commande à partir d'une chaîne Json
	@SuppressWarnings("unchecked")
  public Commande(String json) throws Exception {
		// parsing de la chaîne json
		Map<String, Object> map = new Gson().fromJson(json, new TypeToken<Map<String,Object>>() {
	  }.getType());
		// on récupère les valeurs du dictionnaire
		this.id = (String) map.get("id");
		this.action = (String) map.get("ac");
		this.parametres = (Map<String, Object>) map.get("pa");
	}

	@Override
	public String toString() {
		// on rend la commande au format JSON
		try {
			// on rend la commande au format JSON
			return new Gson().toJson(this);
		} catch (Exception e) {
			return "Problème de conversion en JSON : " + e;
		}
	}

	// conversion en Json
	public String toJson() throws IOException {
		// on rend la commande au format JSON
		return new Gson().toJson(map);
	}

	// getters et setters
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAction() {
		return action;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public Map<String, Object> getParametres() {
		return parametres;
	}

	public void setParametres(Map<String, Object> parametres) {
		this.parametres = parametres;
	}

	public Map<String, Object> getMap() {
		return map;
	}

	public void setMap(Map<String, Object> map) {
		this.map = map;
	}
}
