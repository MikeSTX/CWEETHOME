package istia.st.domotique.entities;

import java.io.Serializable;

public class DomotiqueException extends RuntimeException implements Serializable{

  private static final long serialVersionUID = 1L;
// champs privés
  private int code = 0;
// constructeurs

  public DomotiqueException() {
    super();
  }

  public DomotiqueException(String message) {
    super(message);
  }

  public DomotiqueException(String message, Throwable cause) {
    super(message, cause);
  }

  public DomotiqueException(Throwable cause) {
    super(cause);
  }

  public DomotiqueException(String message, int code) {
    super(message);
    setCode(code);
  }

  public DomotiqueException(Throwable cause, int code) {
    super(cause);
    setCode(code);
  }

  public DomotiqueException(String message, Throwable cause, int code) {
    super(message, cause);
    setCode(code);
  }
// getters - setters

  public int getCode() {
    return code;
  }

  public void setCode(int code) {
    this.code = code;
  }
}