package istia.st.domotique.entities;

import java.io.Serializable;
import java.util.Map;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class Reponse implements Serializable {
  // données

  private static final long serialVersionUID = 1L;
  private String json;
  private String id;
  private String erreur;
  private Map<String, Object> etat;

  // constructeurs
  public Reponse() {
  }

  public Reponse(String json, String id, String erreur, Map<String, Object> etat) {
    this.json = json;
    this.id = id;
    this.erreur = erreur;
    this.etat = etat;
  }

  @SuppressWarnings("unchecked")
  public Reponse(String json) {
    Map<String, Object> map = null;
    try {
      // parsing de la chaîne json
      map = new Gson().fromJson(json, new TypeToken<Map<String, Object>>() {
      }.getType());
      this.id = (String) map.get("id");
      this.erreur = (String) map.get("er");
      this.etat = (Map<String, Object>) map.get("et");
    } catch (Exception ex) {
      this.json = json;
      this.erreur = "json invalide";
    }
  }

  // signature

  @Override
  public String toString() {
    try {
      // on rend la commande au format JSON
      return new Gson().toJson(this);
    } catch (Exception e) {
      return "Problème de conversion en JSON : " + e;
    }
  }

  // getters et setters
  public String getJson() {
    return json;
  }

  public void setJson(String json) {
    this.json = json;
  }

  public String getId() {
    return id;
  }

  public void setId(String id) {
    this.id = id;
  }

  public String getErreur() {
    return erreur;
  }

  public void setErreur(String erreur) {
    this.erreur = erreur;
  }

  public Map<String, Object> getEtat() {
    return etat;
  }

  public void setEtat(Map<String, Object> etat) {
    this.etat = etat;
  }
}
