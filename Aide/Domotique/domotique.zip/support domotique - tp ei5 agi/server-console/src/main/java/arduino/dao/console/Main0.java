package arduino.dao.console;

import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.Reponse;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import arduino.dao.IDao;
import arduino.dao.IThreadDao;

@SuppressWarnings("deprecation")
public class Main0 implements IDao {

	public static void main(String[] args) throws InterruptedException {
		// on instancie la classe [Main0]
		new Main0();
	}

	// constructeur
	public Main0() {
		// on instancie le serveur d'enregistrement
		IThreadDao recorder = (IThreadDao) new XmlBeanFactory(new ClassPathResource("applicationContext.xml"))
				.getBean("recorder");
		// on lui injecte une couche [DAO] fictive
		recorder.setDao(this);
		// on le lance
		new Thread(recorder).start();
	}

	public Collection<Arduino> getArduinos() {
		// TODO Auto-generated method stub
		return null;
	}

	public void addArduino(Arduino arduino) {
		// suivi
		System.out.println(String.format("L'Arduino [%s] a été ajouté", arduino));
	}

	public void removeArduino(String idArduino) {
		// TODO Auto-generated method stub

	}

	public List<Reponse> sendCommandes(String idArduino, List<Commande> commandes) {
		// TODO Auto-generated method stub
		return null;
	}

	public List<String> sendCommandesJson(String idArduino, List<String> commandes) {
		// TODO Auto-generated method stub
		return null;
	}
}