package arduino.dao.console;

import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import arduino.dao.IDao;

public class Main1 {

	public static void main(String[] args) throws InterruptedException {

		// création de la couche [dao]
		IDao dao = (IDao) new ClassPathXmlApplicationContext("applicationContext.xml").getBean("dao");

		// allumer la led
		List<Commande> allumer = new ArrayList<Commande>();
		// allumage pin 13
		Map<String, Object> paramètres = new HashMap<String, Object>();
		paramètres.put("pin", "8");
		paramètres.put("val", "1");
		paramètres.put("mod", "b");
		allumer.add(new Commande("0", "pw", paramètres));

		// éteindre la led
		List<Commande> eteindre = new ArrayList<Commande>();
		// extinction pin 13
		paramètres = new HashMap<String, Object>();
		paramètres.put("pin", "8");
		paramètres.put("val", "0");
		paramètres.put("mod", "b");
		eteindre.add(new Commande("1", "pw", paramètres));

		// état d'une pin
		List<Commande> getPin = new ArrayList<Commande>();
		// état pin 7
		paramètres = new HashMap<String, Object>();
		paramètres.put("pin", "0");
		paramètres.put("mod", "a");
		getPin.add(new Commande("2", "pr", paramètres));

		// boucle infinie de dialogue avec les arduinos connectés
		boolean éteinte = true;
		List<Commande> commandes;
		while (true) {
			// attente
			System.out.println("Main : attente...");
			Thread.sleep(1000);
			// allumage / extinction
			if (éteinte) {
				commandes = allumer;
			} else {
				commandes = eteindre;
			}
			// on bascule
			éteinte = !éteinte;

			// on envoie les commandes aux arduinos enregistrés
			for (Arduino arduino : dao.getArduinos()) {
				// action sur la pin
				sendCommandes(dao, arduino.getId(), commandes);
				// état de la pin
				sendCommandes(dao, arduino.getId(), getPin);
			}
		}
	}

	private static void sendCommandes(IDao dao, String idarduino, List<Commande> commandes) {
		try {
			// envoie les commandes à l'Arduino
			dao.sendCommandes(idarduino, commandes);
		} catch (Exception e) {
		}
	}
}
