package arduino.metier.console;

import istia.st.domotique.entities.Arduino;

import java.util.Collection;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import arduino.metier.IMetier;

public class Clignoter {

	public static void main(String[] args) throws InterruptedException {

		String syntaxe = "Syntaxe : pg pin duréeClignotement nbClignotements";

		// il faut 3 arguments : le n° de pin, la durée du clignotement en millisecondes et le nombre de clignotements
		if (args.length != 3) {
			System.out.println(syntaxe);
			System.exit(0);
		}
		// le n° de pin doit être un entier dans l'intervalle 0-13
		int pin = 0;
		Boolean erreur = false;
		try {
			pin = Integer.parseInt(args[0]);
			if (pin < 1 || pin > 13) {
				erreur = true;
			}
		} catch (NumberFormatException e) {
			erreur = true;
		}
		// erreur ?
		if (erreur) {
			System.out.println("Le n° de pin doit être dans l'intervalle [1,13]");
			System.exit(0);
		}
		// la durée d'un clignotement
		erreur = false;
		int durée = 0;
		try {
			durée = Integer.parseInt(args[1]);
			if (durée < 100 || durée > 2000) {
				erreur = true;
			}
		} catch (NumberFormatException e) {
			erreur = true;
		}
		// erreur ?
		if (erreur) {
			System.out.println("La durée du clignotement en milliseconds doit être dans l'intervalle [100,2000]");
			System.exit(0);
		}
		// le nbre de clignotements
		erreur = false;
		int nbIter = 0;
		try {
			nbIter = Integer.parseInt(args[2]);
			if (nbIter < 2) {
				erreur = true;
			}
		} catch (NumberFormatException e) {
			erreur = true;
		}
		// erreur ?
		if (erreur) {
			System.out.println("Le nombre de clignotements doit être au moins égal à 2");
			System.exit(0);
		}

		// création de la couche [métier]
		IMetier métier = (IMetier) new ClassPathXmlApplicationContext("metierContext.xml").getBean("metier");
		// liste des arduinos
		System.out.println("Attente d'arduinos connectés...");
		Collection<Arduino> arduinos = métier.getArduinos();
		while (arduinos.isEmpty()) {
			// attente d'1 seconde
			Thread.sleep(1000);
			// liste des arduinos
			arduinos = métier.getArduinos();
		}
		// on fait clignoter la pin pin de tous les arduinos nbIter fois avec un intervalle de millis millisecondes
		for (Arduino arduino : arduinos) {
			métier.faireClignoterLed(arduino.getIp(), arduino.getId(), pin, durée, nbIter);
		}
		System.out.println("fin de main");
	}
}
