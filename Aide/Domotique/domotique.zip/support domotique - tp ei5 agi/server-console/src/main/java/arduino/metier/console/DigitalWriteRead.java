package arduino.metier.console;

import istia.st.domotique.entities.Arduino;

import java.util.Collection;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import arduino.metier.IMetier;

public class DigitalWriteRead {

	public static void main(String[] args) throws InterruptedException {

		String syntaxe = "pg pin";

		// il faut 1 argument : le n° de pin
		if (args.length != 1) {
			System.out.println(syntaxe);
			System.exit(0);
		}
		// le n° de pin doit être un entier dans l'intervalle 1-13
		int pin = 0;
		Boolean erreur = false;
		try {
			pin = Integer.parseInt(args[0]);
			if (pin < 1 || pin > 13) {
				erreur = true;
			}
		} catch (NumberFormatException e) {
			erreur = true;
		}
		// erreur ?
		if (erreur) {
			System.out.println("Le n° de pin doit être dans l'intervalle [1,13]");
			System.exit(0);
		}
		// création de la couche [métier]
		IMetier métier = (IMetier) new ClassPathXmlApplicationContext("metierContext.xml").getBean("metier");
		// liste des arduinos
		Collection<Arduino> arduinos = métier.getArduinos();
		while (arduinos.isEmpty()) {
			// attente d'1 seconde
			Thread.sleep(1000);
			// liste des arduinos
			arduinos = métier.getArduinos();
		}
		// on exécute la commande
		for (Arduino arduino : arduinos) {
			// écriture 1
			métier.pinWrite(arduino.getIp(), arduino.getId(), pin, "b", 1);
			// lecture
			métier.pinRead(arduino.getIp(), arduino.getId(), pin, "b");
			// pause
			Thread.sleep(1000);
			// écriture 0
			métier.pinWrite(arduino.getIp(), arduino.getId(), pin, "b", 0);
			// lecture
			métier.pinRead(arduino.getIp(), arduino.getId(), pin, "b");
		}
	}
}
