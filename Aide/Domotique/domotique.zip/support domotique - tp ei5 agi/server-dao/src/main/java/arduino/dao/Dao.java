package arduino.dao;

import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.Reponse;

import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.google.gson.Gson;

public class Dao implements IDao {

	// injections Spring
	private IThreadDao recorder;
	private int timeoutConnection;
	private int timeoutRead;
	private Boolean traced;
	private IThreadDao deadOrAlive;
	// données locales
	// dictionnaire des arduinos
	private Map<String, Arduino> arduinos = new HashMap<String, Arduino>();
	// verrou d'accès à la liste
	final private Object verrou = new Object();
	// mapper Json
	Gson jsonMapper = new Gson();

	// constructeur
	public Dao() {
	}

	// initialisation de la couche [dao]
	@SuppressWarnings("unused")
	private void init() {
		// lance le service d'enregistrement dans un thread à part
		recorder.setDao(this);
		new Thread(recorder).start();
	}

	// liste des Arduinos
	public Collection<Arduino> getArduinos() {
		return null;
	}

	// ajouter un arduino à la liste
	public void addArduino(Arduino arduino) {
		}

	// supprimer un arduino de la liste
	public void removeArduino(String id) {
	}

	// envoyer des commandes à un Arduino
	public List<Reponse> sendCommandes(String idArduino, List<Commande> commandes) {
		return null;
	}

	// envoyer des commandes Json à un arduino
	public List<String> sendCommandesJson(String idArduino, List<String> commandes) {
		return null;
	}

	// pour tracer l'échange avec l'arduino
	private void trace(String message) {
		trace(
				Level.INFO,
				String.format("RestServer Dao SendCommandesJson : [%s] : [%s]",
						new SimpleDateFormat("HH:mm:ss:SS").format(new Date()), message), null);
	}

	// logs
	private void trace(Level level, String message, Exception e) {
		String msg = String.format("Dao : [%s] : [%s]", new SimpleDateFormat("HH:mm:ss:SS").format(new Date()), message);
		if (e == null) {
			Logger.getLogger(Dao.class.getName()).log(level, msg);
		} else {
			Logger.getLogger(Dao.class.getName()).log(level, msg, e);
		}
	}

	// setters pour Spring
	public void setRecorder(IThreadDao recorder) {
		this.recorder = recorder;
	}

	public void setTimeoutConnection(int timeoutConnection) {
		this.timeoutConnection = timeoutConnection;
	}

	public void setTimeoutRead(int timeoutRead) {
		this.timeoutRead = timeoutRead;
	}

	public void setTraced(Boolean traced) {
		this.traced = traced;
	}

	public void setDeadOrAlive(IThreadDao deadOrAlive) {
		this.deadOrAlive = deadOrAlive;
	}
}
