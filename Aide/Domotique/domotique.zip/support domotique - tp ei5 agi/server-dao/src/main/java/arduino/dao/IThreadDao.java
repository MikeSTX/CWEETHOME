package arduino.dao;

// thread lancé par la couche [dao]
public interface IThreadDao extends Runnable {
  // le thread doit connaître la couche [dao]
  public void setDao(IDao dao);
}
