package arduino.dao;

// paquetages
import istia.st.domotique.entities.DomotiqueException;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Recorder implements IThreadDao {

	// injections Spring
	private int nbConnexions;
	private int port;
	private String ip;
	private IDao dao;
	private Boolean traced;

	// données locales
	private InetAddress inetAddress;

	@SuppressWarnings("unused")
	private void init() {
		try {
			// on initialise l'Ip du serveur
			inetAddress = InetAddress.getByName(ip);
		} catch (UnknownHostException e) {
			throw new DomotiqueException("Erreur à l'initialisation de l'IP du serveur", e, 4);
		}
	}

	// ------------------ méthode run
	public void run() {
	}

	// getters et setters
	public void setNbConnexions(int nbConnexions) {
		this.nbConnexions = nbConnexions;
	}

	public void setPort(int port) {
		this.port = port;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}

	public void setDao(IDao dao) {
		this.dao = dao;
	}

	public void setTraced(Boolean traced) {
		this.traced = traced;
	}

}
