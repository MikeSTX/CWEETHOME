package arduino.metier;

import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.Reponse;

import java.util.Collection;
import java.util.List;

import arduino.dao.IDao;

public class Metier implements IMetier {

	// couche [dao]
	private IDao dao;

	public Reponse faireClignoterLed(String idCommande, String idArduino, int pin, int millis, int nbIter) {
		return null;
	}

	// exécuter une suite de commandes
	public List<Reponse> sendCommandes(String idArduino, List<Commande> commandes) {
		return null;
	}

	// exécuter une suite de commandes Json
	public List<String> sendCommandesJson(String idArduino, List<String> commandes) {
		return null;
	}

	// liste des arduinos
	public Collection<Arduino> getArduinos() {
		return null;
	}

	// setter
	public void setDao(IDao dao) {
		this.dao = dao;
	}

	public IDao getDao() {
		return dao;
	}

	public Reponse pinRead(String idCommande, String idArduino, int pin, String mode) {
		return null;
	}

	public Reponse pinWrite(String idCommande, String idArduino, int pin, String mode, int val) {
		return null;
	}
}
