package arduino.rest.metier;

import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.Reponse;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.View;

import arduino.metier.IMetier;

@Controller
public class RestMetier {

	// couche métier
	@Autowired
	private IMetier metier;
	@Autowired
	private View view;

	// liste des arduinos
	@RequestMapping(value = "/arduinos/", method = RequestMethod.GET)
	public ModelAndView getArduinos() {
		return new ModelAndView(view, "data", metier.getArduinos());

	}

	// clignotement
	@RequestMapping(value = "/arduinos/blink/{idCommande}/{idArduino}/{pin}/{duree}/{nombre}", method = RequestMethod.GET)
	public ModelAndView faireClignoterLed(@PathVariable("idCommande") String idCommande,
			@PathVariable("idArduino") String idArduino, @PathVariable("pin") String pin,
			@PathVariable("duree") String duree, @PathVariable("nombre") String nombre) {
		return null;
	}

	// envoi de commandes JSON
	@RequestMapping(value = "/arduinos/commands/{idArduino}", method = RequestMethod.POST, consumes = "application/json")
	public ModelAndView sendCommandesJson(@PathVariable("idArduino") String idArduino,
			@RequestBody List<Map<String, String>> commandes) {
		return null;
	}

	public List<Reponse> sendCommandes(String idArduino, List<Commande> commandes) {
		return null;
	}

	// setter
	public void setMetier(IMetier metier) {
		this.metier = metier;
	}

	// lecture pin
	@RequestMapping(value = "/arduinos/pinRead/{idCommande}/{idArduino}/{pin}/{mode}", method = RequestMethod.GET)
	public ModelAndView pinRead(@PathVariable("idCommande") String idCommande,
			@PathVariable("idArduino") String idArduino, @PathVariable("pin") String pin, @PathVariable("mode") String mode) {
		return null;
	}

	// écriture pin
	@RequestMapping(value = "/arduinos/pinWrite/{idCommande}/{idArduino}/{pin}/{mode}/{valeur}", method = RequestMethod.GET)
	public ModelAndView pinWrite(@PathVariable("idCommande") String idCommande,
			@PathVariable("idArduino") String idArduino, @PathVariable("pin") String pin, @PathVariable("mode") String mode,
			@PathVariable("valeur") String valeur) {
		return null;
	}

	// crée une réponse d'erreur
	private ModelAndView createResponseError(String numero, String message) {
		Map<String, Object> modèle = new HashMap<String, Object>();
		modèle.put("error", numero);
		modèle.put("message", message);
		return new ModelAndView(view, modèle);
	}
}
