package arduino.restClient.console;

import istia.st.domotique.entities.Arduino;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import client.rest.metier.IMetier;

public class FaireClignoterLed {

  public static void main(String[] args) {
  	// instanciation client REST
    IMetier metier = (IMetier) new ClassPathXmlApplicationContext("spring-restClient.xml").getBean("metier");
    int i = 0;
    // on fait clignoter la led des Arduinos
    for (Arduino arduino : metier.getArduinos()) {
      System.out.println(metier.faireClignoterLed(String.valueOf(i), arduino.getId(), 8, 100, 10));
      i++;
    }
  }
}
