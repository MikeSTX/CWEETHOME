package arduino.restClient.console;

import istia.st.domotique.entities.Arduino;

import java.util.Collection;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import client.rest.metier.IMetier;

public class ListArduinos {

	public static void main(String[] args) {
		IMetier metier = (IMetier) new ClassPathXmlApplicationContext("spring-restClient.xml").getBean("metier");
		System.out.println("Liste des Arduinos connectés");
		Collection<Arduino> arduinos = metier.getArduinos();
		if (arduinos.size() == 0) {
			System.out.println("Aucun Arduino n'est connecté actuellement...");
		} else {
			for (Arduino arduino : arduinos) {
				System.out.println(arduino);
			}
		}
	}
}
