package arduino.restClient.console;

import istia.st.domotique.entities.Arduino;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import client.rest.metier.IMetier;

public class PinWriteBinaire {

	public static void main(String[] args) throws InterruptedException {
		// instanciation client REST
		IMetier metier = (IMetier) new ClassPathXmlApplicationContext("spring-restClient.xml").getBean("metier");
		for (int i = 1; i < 10; i++) {
			// pour chaque Arduino connecté
			for (Arduino arduino : metier.getArduinos()) {
				// on allume la led
				try {
					System.out.println(metier.pinWrite(String.valueOf(i), arduino.getId(), 8, "b", 1));
				} catch (Exception ex) {
					System.out.println(ex);
				}
				// attente d'1 seconde
				Thread.sleep(100);
				// on éteint la led
				try {
					System.out.println(metier.pinWrite(String.valueOf(i), arduino.getId(), 8, "b", 0));
				} catch (Exception ex) {
					System.out.println(ex);
				}
				Thread.sleep(100);
			}
		}
	}
}
