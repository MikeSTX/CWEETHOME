package arduino.restClient.console;

import istia.st.domotique.entities.Arduino;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import client.rest.metier.IMetier;

import com.google.gson.Gson;

public class SendCommandesJson {

	public static void main(String[] args) throws IOException, InterruptedException {
		// bibliothèque Gson
		Gson mapper = new Gson();
		// instanciation client REST
		IMetier metier = (IMetier) new ClassPathXmlApplicationContext("spring-restClient.xml").getBean("metier");
		// préparation commande allumer
		Map<String, Object> allumer = new HashMap<String, Object>();
		allumer.put("id", "1");
		allumer.put("ac", "pw");
		Map<String, String> params = new HashMap<String, String>();
		params.put("val", "1");
		params.put("pin", "8");
		params.put("mod", "b");
		allumer.put("pa", params);
		// préparation commande eteindre
		Map<String, Object> eteindre = new HashMap<String, Object>();
		eteindre.put("id", "2");
		eteindre.put("ac", "pw");
		params = new HashMap<String, String>();
		params.put("val", "0");
		params.put("pin", "8");
		params.put("mod", "b");
		eteindre.put("pa", params);
		List<String> commandes = new ArrayList<String>();
		// pour chaque Arduino connecté
		for (Arduino arduino : metier.getArduinos()) {
			// on allume
			commandes.clear();
			commandes.add(mapper.toJson(allumer));
			for (String réponse : metier.sendCommandesJson(arduino.getId(), commandes)) {
				System.out.println(réponse);
			}
			// attente d'1 seconde
			Thread.sleep(1000);
			// on éteint
			commandes.clear();
			commandes.add(mapper.toJson(eteindre));
			for (String réponse : metier.sendCommandesJson(arduino.getId(), commandes)) {
				System.out.println(réponse);
			}
			// attente d'1 seconde
			Thread.sleep(1000);
		}
	}
}
