package arduino.jsf.beans;

import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.Reponse;

import java.io.Serializable;
import java.util.Collection;
import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import client.rest.metier.IMetier;

public class ApplicationData implements IMetier, Serializable {
  // couche [métier]

	private static final long serialVersionUID = 1L;
	private IMetier metier;

  // initialisation
  @PostConstruct
  public void init() {
    // couche métier
    metier = (IMetier) new ClassPathXmlApplicationContext("spring-restClient.xml").getBean("metier");
  }

  @Override
  public Collection<Arduino> getArduinos() {
    return metier.getArduinos();
  }

  @Override
  public Reponse pinRead(String idCommande, String idArduino, int pin, String mode) {
    return metier.pinRead(idCommande, idArduino, pin, mode);
  }

  @Override
  public Reponse pinWrite(String idCommande, String idArduino, int pin, String mode, int val) {
    return metier.pinWrite(idCommande, idArduino, pin, mode, val);
  }

  @Override
  public Reponse faireClignoterLed(String idCommande, String idArduino, int pin, int millis, int nbIter) {
    return metier.faireClignoterLed(idCommande, idArduino, pin, millis, nbIter);
  }

  @Override
  public List<String> sendCommandesJson(String idArduino, List<String> commandes) {
    return metier.sendCommandesJson(idArduino, commandes);
  }

  @Override
  public List<Reponse> sendCommandes(String idArduino, List<Commande> commandes) {
    return metier.sendCommandes(idArduino, commandes);
  }
}
