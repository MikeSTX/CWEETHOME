package arduino.jsf.beans;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;

public class RequestData {
	// autres beans - initialisés par JSF

	private ApplicationData applicationData;
	// Json
	Gson jsonMapper = new Gson();
	// valeurs postées
	private String[] selectedArduinosIds;
	private String dureeClignotement;
	private String nbClignotements;
	private String cmdJson;
	private int pin;
	private String mode = "b";
	private int value;
	// modèle de la page
	private List<String> réponses;
	private String[] pins = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10", "11", "12", "13" };
	private String jsonMessageKey = "json.commande.error";
	private String pinMessageKey;
	private String valueMessageKey;
	private List<String> exceptions;

	// gestionnaires d'évts
	// on fixe la valeur d'une pin les arduinos sélectionnés
	public String pinWrite() {
		return null;
	}

	// on lit la valeur d'une pin les arduinos sélectionnés
	public String pinRead() {
		return null;
	}

	// on fait clignoter les arduinos sélectionnés
	public String clignoter() throws IOException {
		// raz page
		réponses = new ArrayList<String>();
		exceptions = new ArrayList<String>();
		// exécution de la commande sur les arduinos sélectionnés
		for (String arduinoId : selectedArduinosIds) {
			// exécution de la commande
			try {
				réponses.add(applicationData.faireClignoterLed(arduinoId, arduinoId, pin, Integer.parseInt(dureeClignotement),
						Integer.parseInt(nbClignotements)).toString());
			} catch (Exception ex) {
				// on mémorise l'exception
				recordException(ex);
			}
		}
		// même page
		return null;
	}

	// exécuter une commande Json
	public String executerCommandeJson() {
		return null;
	}

	// mémoriser la pile des exceptions
	private void recordException(Exception ex) {
		// on enregistre la pile des exceptions
		Throwable th = ex;
		while (th != null) {
			exceptions.add(th.getMessage());
			th = th.getCause();
		}
	}

	// getters et setters
	public String[] getSelectedArduinosIds() {
		return selectedArduinosIds;
	}

	public void setSelectedArduinosIds(String[] selectedArduinosIds) {
		this.selectedArduinosIds = selectedArduinosIds;
	}

	public List<String> getRéponses() {
		return réponses;
	}

	public void setRéponses(List<String> réponses) {
		this.réponses = réponses;
	}

	public void setApplicationData(ApplicationData applicationData) {
		this.applicationData = applicationData;
	}

	public String getDureeClignotement() {
		return dureeClignotement;
	}

	public void setDureeClignotement(String dureeClignotement) {
		this.dureeClignotement = dureeClignotement;
	}

	public String getNbClignotements() {
		return nbClignotements;
	}

	public void setNbClignotements(String nbClignotements) {
		this.nbClignotements = nbClignotements;
	}

	public String getCmdJson() {
		return cmdJson;
	}

	public void setCmdJson(String cmdJson) {
		this.cmdJson = cmdJson;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String[] getPins() {
		return pins;
	}

	public String getMode() {
		return mode;
	}

	public void setMode(String mode) {
		this.mode = mode;
	}

	public int getValue() {
		return value;
	}

	public void setValue(int value) {
		this.value = value;
	}

	public String getJsonMessageKey() {
		return jsonMessageKey;
	}

	public String getPinMessageKey() {
		return pinMessageKey;
	}

	public String getValueMessageKey() {
		return valueMessageKey;
	}

	public List<String> getExceptions() {
		return exceptions;
	}

	public void setExceptions(List<String> exceptions) {
		this.exceptions = exceptions;
	}
}
