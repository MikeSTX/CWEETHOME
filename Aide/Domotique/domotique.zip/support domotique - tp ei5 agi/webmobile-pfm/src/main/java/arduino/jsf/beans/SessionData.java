package arduino.jsf.beans;


public class SessionData {
  // données de session
  String locale="fr";
  
  // getters / setters

  public String getLocale() {
    return locale;
  }

  public void setLocale(String locale) {
    this.locale = locale;
  }
  
}
