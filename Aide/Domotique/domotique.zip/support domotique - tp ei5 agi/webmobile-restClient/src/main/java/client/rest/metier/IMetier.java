package client.rest.metier;

import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.Reponse;

import java.util.Collection;
import java.util.List;

public interface IMetier {
  // liste des arduinos
  public Collection<Arduino> getArduinos();
  // lecture d'une pin
  public Reponse pinRead(String idCommande, String idArduino, int pin, String mode);
  // écriture d'une pin
  public Reponse pinWrite(String idCommande, String idArduino, int pin, String mode,int val);
  // faire clignoter une led
  public Reponse faireClignoterLed(String idCommande, String idArduino, int pin, int millis, int nbIter);
  // envoyer une suite de commandes Json à un Arduino
  public List<String> sendCommandesJson(String idArduino, List<String> commandes);
  // envoyer une suite de commandes à un Arduino
  public List<Reponse> sendCommandes(String idArduino, List<Commande> commandes);
}
