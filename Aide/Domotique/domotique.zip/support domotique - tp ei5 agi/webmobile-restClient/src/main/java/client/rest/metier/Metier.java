package client.rest.metier;

import istia.st.domotique.entities.Arduino;
import istia.st.domotique.entities.Commande;
import istia.st.domotique.entities.Reponse;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.web.client.RestTemplate;

public class Metier implements IMetier {

	// client REST
	private RestTemplate restTemplate;
	// mapper JSON
	private ObjectMapper mapper = new ObjectMapper();
	// ip service REST
	private String urlServiceRest;

	// constructeur
	public Metier() {
	}

	public Collection<Arduino> getArduinos() {
		return null;
	}

	public Reponse pinRead(String idCommande, String idArduino, int pin, String mode) {
		return null;
	}

	public Reponse pinWrite(String idCommande, String idArduino, int pin, String mode, int val) {
		return null;
	}

	public Reponse faireClignoterLed(String idCommande, String idArduino, int pin, int millis, int nbIter) {
		return null;
	}

	public List<String> sendCommandesJson(String idArduino, List<String> commandes) {
		return null;
	}

	public List<Reponse> sendCommandes(String idArduino, List<Commande> commandes) {
		return null;
	}

	private String executeRestService(String method, String urlService, Object request, Map paramètres) {
		return null;
	}

	// setters Spring

	public void setRestTemplate(RestTemplate restTemplate) {
		this.restTemplate = restTemplate;
	}

	public void setUrlServiceRest(String urlServiceRest) {
		this.urlServiceRest = urlServiceRest;
	}

}
